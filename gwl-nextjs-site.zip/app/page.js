export default function Home() {
  return (
    <main style={{ padding: '40px', fontFamily: 'Arial' }}>
      <h1>Gary Wilson</h1>
      <h2>Estate Planning Attorney</h2>
      <p>Professional estate planning services.</p>
    </main>
  );
}