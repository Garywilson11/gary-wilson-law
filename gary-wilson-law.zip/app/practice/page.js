export default function Practice() {
  return (
    <section>
      <h1>Practice Areas</h1>
      <ul>
        <li>Wills</li>
        <li>Trusts</li>
        <li>Business Succession Planning</li>
        <li>Estate Administration</li>
        <li>Asset Protection</li>
      </ul>
    </section>
  );
}
