export default function About() {
  return (
    <section>
      <h1>About Gary Wilson</h1>
      <p>
        Gary Wilson is a California-based Estate Planning Attorney with 18 years
        of experience in wills, trusts, and asset protection.
      </p>
    </section>
  );
}
