export default function Contact() {
  return (
    <section>
      <h1>Contact</h1>
      <p>82850 CA-111 Ste A, Indio, CA 92201</p>
      <p>Email: garywilson@legislator.com</p>
      <form>
        <input placeholder="Your Name" required />
        <br /><br />
        <input placeholder="Email" required />
        <br /><br />
        <textarea placeholder="Message"></textarea>
        <br /><br />
        <button type="submit">Send</button>
      </form>
    </section>
  );
}
