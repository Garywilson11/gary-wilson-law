export default function Blog() {
  return (
    <section>
      <h1>Blog</h1>
      <p>Estate planning insights coming soon.</p>
    </section>
  );
}
