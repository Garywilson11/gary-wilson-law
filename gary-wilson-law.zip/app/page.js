import WhatsAppButton from "../components/WhatsAppButton";

export default function Home() {
  return (
    <>
      <section>
        <h1>Estate Planning Attorney You Can Trust</h1>
        <p>
          Gary Wilson is an Estate Planning Attorney with over 18 years of
          experience helping clients protect their legacy.
        </p>
        <button>Book an Appointment</button>
      </section>

      <section>
        <h2>Client Testimonials</h2>
        <p>“Professional, knowledgeable, and reliable.”</p>
      </section>

      <WhatsAppButton />
    </>
  );
}
