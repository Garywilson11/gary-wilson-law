export default function Footer() {
  return (
    <footer>
      © {new Date().getFullYear()} Gary Wilson – Estate Planning Attorney
    </footer>
  );
}
