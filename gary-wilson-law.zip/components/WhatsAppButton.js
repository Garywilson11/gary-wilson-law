export default function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/XXXXXXXXXX"
      style={{
        position: "fixed",
        bottom: "20px",
        right: "20px",
        background: "#25D366",
        color: "white",
        padding: "15px",
        borderRadius: "50%",
      }}
    >
      WhatsApp
    </a>
  );
}
